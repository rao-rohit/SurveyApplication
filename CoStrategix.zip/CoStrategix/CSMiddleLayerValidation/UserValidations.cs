﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSMiddleLayerValidation
{
    class UserValidations
    {
    }
}
