﻿using System;

namespace CSIDAL
{
    public class Class1
    {
    }
}
