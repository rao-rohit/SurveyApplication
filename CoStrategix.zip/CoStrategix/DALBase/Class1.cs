﻿using System;

namespace DALBase
{
    public class Class1
    {
    }
}
